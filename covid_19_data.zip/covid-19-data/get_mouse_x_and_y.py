import pyautogui, time
while True:
    print(pyautogui.position())